const a = "Rajesh";
const b = "Suneel";
const c = "Sonal";
const d = "situ";

export default a;
export { a };
export { b };
export { c };
