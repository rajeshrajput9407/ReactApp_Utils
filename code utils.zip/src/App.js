// import logo from "./logo.svg";
import "./App.css";
import Navbar from "./Components/Navbar";
import Form from "./Components/Form";

import About from "./Components/About";
import React, { useState } from "react"; //imrs
import AlertMessage from "./Components/AlertMessage";

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import {toast} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
// toast-configuration method,
 // it is compulsory method.
toast.configure()



function App() {
  //Start mode state
  const [mode, setMode] = useState("light");
  const toggleMode = (clsName) => {
    console.log(clsName);
    if (mode==="dark") {
      setMode("light");
      document.body.style.backgroundColor = "white";
      ShowAlert("Light Mode Has Enabled","success");
      // notify("Light Mode Enable Succussfully.","s");
      document.title = "Text-Utils: Light Mode";
    } else { 
      setMode("dark");
      document.body.style.backgroundColor = "#042743"; 
      ShowAlert("Dark Mode Has Enabled","success");
      // notify("Dark Mode Enable Succussfully.","s");
      document.title = "Text-Utils: Dark Mode";
    }
  }
  const notify = (message,type)=>{
    if (type === "s") { 
      toast.success(message);
    }
    if (type === "e") { 
      toast.error(message);
    }
    if (type === "w") { 
      toast.warning(message);
    }
  }
  
  // Start Alert Message
  const [Alert, setAlert] = useState(null);
  const ShowAlert = (message,type) => { 
    setAlert({
      Message : message,
      Type: type
    });
    setTimeout(() => {
      setAlert(null);
    }, 2000);
  }

  return (
    <>
      <Router>
      <Navbar logoName="My_LOGO" mode={mode} toggleMode={toggleMode} />
       <AlertMessage Alert = {Alert}/>
      <div className="container">
        <div className="row">
          <div className="col">
              <Routes>
                {/* users--> comp1  without exact will render partially routing, always render 1
                    users/home--> comp2
                */}
                <Route exact path="/about" element={<About />} />
                <Route exact path="/" element={ <Form heading="Enter Text For Analys" mode={mode} notify={ notify}/>} />
            </Routes>
           {/* <Form heading="Enter Text For Analys" mode={mode} notify={ notify}/> */}
            {/* <About /> */}
          </div>
        </div>
        </div>
        </Router>
    </>
  );
}
export default App;