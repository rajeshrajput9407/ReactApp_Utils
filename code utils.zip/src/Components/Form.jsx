import React, { useState } from "react";
console.log(useState);
//rfc sortcut
export default function Form(props) {
  const handleClick = () => {
    debugger;
    console.log("Click Upper Button " + text);
    let newUText = text.toUpperCase(text);
    setText(newUText);
    props.notify("Convert To Upper Case Successfully", "s");
  };
  const handleLCClick = () => {
    console.log("Click Lower Button " + text);
    let newLText = text.toLowerCase(text);
    setText(newLText);
    props.notify("Convert To Lower Case Successfully", "s");
  };

  const handleOnChangeText = (event) => {
    console.log("handle On Change Text");
    setText(event.target.value);
  };
  // const handleOnChangeText2 = (event) => {
  //   console.log("handle On Change Text");
  //   setText2(event.target.value);
  // };
  const handleCleanTextClick = () => {
    console.log("Click clean Button ");
    setText("");
    props.notify("Text Clear Successfully", "s");
  };
  const handleCopyText = () => {
    debugger;
    console.log("Click handleCopyText Button");
    navigator.clipboard.writeText(text);
    props.notify("Text Copy Successfully", "s");
  };
  const handleRemoveExtraSpace = () => {
    debugger;
    console.log("Click handleRemoveExtraSpace Button");
    setText(text.replace(/\s+/g, " "));
    props.notify("Remove Extra Space Successfully", "s");
  };
  const [text, setText] = useState(""); //states
  // const [text2, setText2] = useState("this is sample");

  return (
    <>
  <div className="className my-6" style={{color:props.mode==='light'?'black':'white'}}>
   <h1>{props.heading}</h1>
   <div className="mb-3">
     <textarea className="form-control" value={text} onChange={handleOnChangeText} id="myform" rows="8" style={{backgroundColor:props.mode==='light'?'White':'#33CCFF'}}></textarea> {/* <textarea className="form-control" value={text2} onChange={handleOnChangeText2} id="myform" rows="8"></textarea> */}
   </div>
   <button className="btn btn-sm btn-success mx-1 my-1" onClick={handleClick}> Convert to UpperCase </button>
   <button className="btn btn-sm btn-success mx-1 my-1" onClick={handleLCClick}> Convert to LowerCase </button>
   <button className="btn btn-sm btn-success mx-1 my-1" onClick={handleCopyText}> Copy Text </button>
   <button className="btn btn-sm btn-success mx-1 my-1" onClick={handleRemoveExtraSpace}> Remove Extra Space </button>
   <button className="btn btn-sm btn-danger mx-1 my-1" onClick={handleCleanTextClick}> Clean Text </button>
 </div>
 <div className="className my-2" style={{color:props.mode==='light'?'black':'white'}}>
   <h2>Status of your Content</h2>
   <p > {text.split(/\s+/).filter((element)=>{return element.length !== 0}).length} Words and {text.length} characters </p>
   <p>{0.008 * text.split(" ").length} :Min reads</p>
   <div>
          <h2>Preview:</h2>
          <p>{text.length>0?text:"Enter text for preview"}</p>
   </div>
 </div>
     </>
  );
}
