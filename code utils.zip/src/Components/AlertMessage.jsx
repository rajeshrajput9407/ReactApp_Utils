import React from 'react'

export default function AlertMessage(props) {
    return (
        props.Alert &&  <>
       <div className={`alert alert-${props.Alert.Type} alert-dismissible fade show`} role="alert">
             <strong>{ props.Alert.Message}</strong>
            {/* <button type="button" className="btn-close" data-bs-dismiss="alert" aria-label="Close"></button> */}
        </div>
    </>
    )
}
