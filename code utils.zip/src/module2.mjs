import ui, { a, b, c } from "./module1.mjs";
console.log(ui);
console.log(a);
console.log(b);
console.log(c);
